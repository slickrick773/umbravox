# XIAO node validation — 2026-11-03

Firmware source: c2bf4e58d33cde62dfa1d7e7aba5de0d89f238cf.
Target: xiao-c5-node, Seeed Studio XIAO ESP32-C5, 8 MB flash.
Peer: Waveshare ESP32-C5-Touch-LCD-3.5 running published bce092c firmware.

- PlatformIO build passed; application is 1,041,664 bytes in a 3 MiB slot.
- Full host test suite (`make -C sim test`) passed.
- All four XIAO images written and verified with esptool 5.6.0, ROM/no-stub mode.
- Node booted, joined the open network and received 20 assigned channels.
- Node applied the handheld's ACTIVE mode and 150 ms dwell setting.
- During a 40-second observation, handheld accepted-report count increased
  from 217 to 473. Rejected magic/version/length/no-slot counters stayed zero.
- Node counters increased from 1,555 to 3,356 records sent, with zero reported
  queue drops and send failures throughout the observed window. These are
  record counters, not unique network counts.

- After a software reset, the node rejoined, reapplied ACTIVE/150 ms and resumed
  reports (555 records sent, zero drops/failures in the restart observation).

Passive/220 ms switching and private-network enrollment were not exercised.

Scope: one node and one handheld on the bench, without GPS. This does not
establish multi-node capacity, field performance, GPS recording, or NM/2.8-inch
hardware acceptance for this exact node binary. Matching protocol/source was
checked for those handheld builds. The handheld emitted I2C errors during the
run; their cause was not established by this node validation.
