# NM-CYD-C5 native UI — 45e7ed3

The shared adaptive UI engine, rendered natively at 320x240 in landscape.
This package is for NM-CYD-C5 only, NOT a Waveshare or XIAO board.
Host-tested and build-tested; not yet hardware-validated on NM.

SCAN, DOMAIN, CODEX/AP details, Menu, Files, settings, Alerts and themes use
one shared renderer with the Waveshare targets. Native bridge, client/probe
views and capture/export paths are enabled. NM keeps XPT2046 resistive touch,
UART GPS and its own display pins. Battery sensing is unavailable. Native
portrait is not enabled. See NM-NATIVE-ENGINE.md for integration details.

Requires 16 MiB physical flash and the configured 8 MiB PSRAM board.
Firmware: 3,174,592 bytes in a 6 MiB app slot.

## Before installation

Use the board's CH340 UART connection; this build disables USB CDC for Serial.
Stop recording and disconnect other boards. Extract this ZIP, then open a
terminal in its folder. Use esptool 5.6.0 in your Python environment:
`python -m pip install esptool==5.6.0`.
Replace PORT below with the actual serial port. Do not type PORT literally.

Verify all files with `shasum -a 256 -c SHA256SUMS.txt` on macOS/Linux;
on Windows compare `Get-FileHash -Algorithm SHA256` against that list.

```sh
python -m esptool --chip esp32c5 --port PORT --no-stub flash-id
```

Back up the existing firmware and settings before writing. For a confirmed
16 MiB board (adjust read size to actual physical capacity if different):

```sh
python -m esptool --chip esp32c5 --port PORT --baud 115200 read-flash 0x0 0x1000000 before-flash.bin
```

Keep this backup private; it can contain settings or credentials. If the board
has less than 16 MiB, do not flash this configured image without a separately
reviewed build. If automatic connection fails, enter download mode with BOOT
held while pressing/releasing RESET, then release BOOT and retry.

## First install or unmatched partition table

Use the four matching files from THIS NM package:

```sh
python -m esptool --chip esp32c5 --port PORT --baud 115200 --no-stub write-flash 0x2000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
```

This is the NM native-engine partition migration. The old 3 MiB app slot is
replaced with 6 MiB app slots. An app-only first installation is not sufficient. No erase-all is used. These writes
skip NVS at 0x9000–0xdfff and do not write the external SD card. Existing umbravox
settings may be retained; unrelated firmware settings are not guaranteed
compatible. boot_app0 resets boot selection to app0. Back up any internal data
before replacing a different partition layout.

## App-only update with matching NM partition table

Only use this if the installed partition table matches this package and the
board boots app0 at 0x10000. To compare the partition bytes:

```sh
python -m esptool --chip esp32c5 --port PORT --baud 115200 read-flash 0x8000 0xc00 installed-partitions.bin
```

Compare its SHA-256 with partitions.bin in SHA256SUMS.txt. If uncertain, use the
full matching-file procedure after backup. Then the app-only write is:

```sh
python -m esptool --chip esp32c5 --port PORT --baud 115200 --no-stub write-flash 0x10000 firmware.bin
```

## Verification before normal use

Use CH340 serial at 115200. Verify stable startup, colors, orientation,
corner/center taps, repeated navigation, SD recording and export, themes,
UART GPS with a connected receiver, bridge and node operation.
Host previews use synthetic data and are not hardware photographs.

## Source and validation

Exact source commit: 45e7ed3827d0b347353837793ead3f237d9ed715
Build: `pio run -e nm-cyd-c5-engine`
Source is included in source.tar.gz, licensed GPL-3.0.
The full host suite passed, plus the NM-specific bridge identity test.
Both Waveshare engine targets and the legacy NM target also compiled.
The working Waveshare baseline bce092c remains in history.
No board was flashed and no public release was replaced for this delivery.
