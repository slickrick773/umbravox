# UMBRAVOX candidate firmware

Board target: ws-c5-28-engine
Source revision: a802b6453352d6807b12e9024a3854bea7e2c23e

Install using the matching browser installer manifest. Four image offsets: bootloader 0x2000, partitions 0x8000, boot_app0 0xe000, firmware 0x10000.

Use esptool 5.6.0 for command-line installation. No full-chip erase is required. Existing enrollment is retained.

See docs/BLE-BRIDGE.md and docs/XIAO-NODE-VALIDATION.md in the source archive for bounded validation. After GPS I2C faults across resets, fully remove handheld and GPS power for 30 seconds before restarting. The original GPS driver is retained; timing experiments were rejected.
