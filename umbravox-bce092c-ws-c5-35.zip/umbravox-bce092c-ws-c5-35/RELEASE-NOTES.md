# umbravox — RF discovery, wardriving & network exploration
## bce092c · prerelease

See what’s on the air. Discover Wi-Fi and Bluetooth LE devices, explore networks in detail, map observations, and save captures for analysis. Use umbravox on its own, connect it to your wardriving app, or expand coverage with coordinated scanning nodes.

Built on Em3ritus/umbravox. GPL-3.0. The feature overview below describes the Waveshare native builds; the separate NM candidate retains its legacy interface.

## Preview

Stock UMBRAVOX, equal-size 480×320 production-renderer previews. Synthetic demonstration data, not hardware photographs.

![Stock UMBRAVOX: SCAN (left) and CODEX (right)](https://github.com/slickrick773/umbravox/releases/download/bce092c/umbravox-preview.png)

## Discover and inspect

- **Dual-band Wi-Fi discovery:** scan 2.4 GHz and supported 5 GHz channels, with selectable active/passive scanning and configurable dwell timing. Active mode transmits probe requests; hidden network names are not guaranteed to resolve.
- **Bluetooth LE discovery:** observe nearby advertisements alongside Wi-Fi scanning, with configurable scan allocation.
- **SCAN:** live Wi-Fi/5 GHz/BLE counts, channel activity bars and a theme-aware signal field. The SCAN field visualizes signal activity, not measured direction or distance.
- **CODEX:** browse discovered devices, sort APs by signal strength, and open full AP details including SSID, BSSID, channel, RSSI and security information.
- **Deeper AP details:** vendor/OUI lookup, signal history, first/last observation ages, advertised PHY capabilities and channel width, country, beacon interval and WPS information when available in received frames.
- **DOMAIN:** browse located APs with a geographic view, adjustable range and access to full AP details. Locations require available location evidence; unknown positions are not invented.
- **Clients and probes:** inspect observed station/AP relationships and requested network names. Hidden-name resolution uses captured evidence; a probe alone does not prove association.
- **Alerts:** review signature matches with evidence and confidence, plus a clearly labeled test alert. A vendor or signature match is an indication, not proof of a device's owner or purpose.

## Record and export

- WiGLE-compatible Wi-Fi CSV recordings.
- GPX tracks from valid GPS fixes during recording.
- Client and probe CSV companion files.
- Raw 802.11 PCAP capture for inspection in Wireshark, controlled separately from normal recording.
- A dedicated **POI** action for marking points of interest.
- Organized session and capture folders on SD, with a Files browser, access to legacy recordings, and protection against deleting files that are still in use.

## Connect your phone and nodes

- **WarDriveGo and Biscuit BLE bridge:** stream Wi-Fi observations to the selected phone app. Toggle the bridge from the header; the phone supplies location for its own records. This is not a BLE-device or raw-PCAP export stream.
- **Coordinated scanning nodes:** distribute channel work and configure scanning mode/dwell from the handheld.
- **Nodes diagnostics:** inspect applied versus requested settings, report freshness, queue occupancy/drops and delivery failures.
- Bridge streaming, local scanning and SD recording have separate controls. Stopping recording does not stop discovery.

## A touchscreen interface built for both Waveshares

- Native landscape layouts at **480×320** and **320×240**.
- Persistent navigation, scrolling lists and full AP detail pages.
- Header GPS, Nodes, bridge, SD and battery indicators; absent batteries do not display a fabricated charge level.
- Dedicated Scanning, Recording, Bridge and Nodes settings pages.
- Separate display/touch controls for brightness, idle behavior and touch testing.
- Bundled general and crew themes, plus SD theme-pack support. The release screenshots use the stock **UMBRAVOX** theme.

## Choose your download

| Package | Board | Status |
| --- | --- | --- |
| ws-c5-35 | Waveshare ESP32-C5-Touch-LCD-3.5 | Hash-verified flash; startup checks passed |
| ws-c5-28 | Waveshare ESP32-C5-Touch-LCD-2.8 | Hash-verified flash; startup checks passed |
| nm-cyd-c5 | NM-CYD-C5 | Build-tested candidate; NOT hardware-validated |

NM retains its 160×120 canvas at 2× and 3 MiB app slot. It does not include the Waveshare UI engine; no UI/feature parity is claimed. No XIAO node binary is included in this release.

Each board ZIP contains installation instructions, matching firmware/boot artifacts, checksums, LICENSE and the exact source snapshot. A separate source archive is also provided.

## Installation

Follow the README in the ZIP for your exact board. **First-time Waveshare installation or migration from the old 3 MiB app slot requires the matching bootloader, partition table, boot_app0 and application. An app-only flash cannot resize a partition.**

Waveshare packages require at least 16 MiB flash and use two 6 MiB application slots within a 16 MiB layout. OTA is not implemented; the second slot is reserved. On tested 32 MiB boards, the upper 16 MiB remains unallocated. Waveshare migration instructions do not apply to NM. Flashing does not update external SD theme overrides.

## Validation and known limits

- This release was flashed with hash verification to two Waveshare 3.5-inch boards and one Waveshare 2.8-inch board. Bounded startup captures confirmed SD mounting, touch-controller initialization, display-engine activity and increasing Wi-Fi/BLE discovery counts on all three; touch input events were also recorded on the primary 3.5-inch board. No repeated boot or panic appeared in those captures. NM remains build-tested only.
- The host test suite and all three target builds passed again for this correction. The release artifacts, including nested archives and firmware binaries, are checked against the installed privacy guard. Prior hardware acceptance is bounded, not a long-duration soak guarantee.
- Testing confirmed one XIAO node reconnecting without re-enrollment and applying a coordinator-requested dwell change from 220 ms to 150 ms. Extended multi-node testing and a controlled comparison of those dwell settings have not been completed.
- Native portrait mode, OTA updating and direct WiGLE/WDG Wars/Wardrift API uploads are not included.
- AP metadata depends on received evidence. Active scans and relayed observations do not supply every advertised field.

## Screenshots and source

Two stock-UMBRAVOX screenshots show SCAN and CODEX at 480×320. These are production-renderer previews using synthetic demonstration data, not hardware photographs or NM screenshots.

Source: https://github.com/slickrick773/umbravox/tree/bce092cc3c4c833d4fa895cbac4f863ff898f2ad

Source artwork retains previously accepted C2PA provenance metadata. Current test fixtures are sanitized; the attached source snapshot contains no Git history.
