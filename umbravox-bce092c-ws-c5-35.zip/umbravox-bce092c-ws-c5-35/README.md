# Waveshare ESP32-C5-Touch-LCD-3.5

Build **bce092c**, environment `ws-c5-35-engine`. Use ONLY on this board model.
Minimum physical flash: 16 MiB. Tested hardware: 32 MiB.

## Prepare

Stop recording, disconnect other boards, and select the intended USB serial port.
Extract this ZIP and open a terminal in this folder. Install esptool 5.6.0
(`python -m pip install esptool==5.6.0` in your Python environment). Replace
`PORT` below with your actual port; it is not a literal device name.

Verify this package: `shasum -a 256 -c SHA256SUMS.txt` on macOS/Linux, or compare
`Get-FileHash -Algorithm SHA256` results on Windows. Check ALL files before writing.

```sh
python -m esptool --chip esp32c5 --port PORT --no-stub flash-id
```

Confirm capacity >=16 MiB. Save the output and board identity locally. Back up
existing flash before changing partitions. For a confirmed 32 MiB board:

```sh
python -m esptool --chip esp32c5 --port PORT --baud 460800 read-flash 0x0 0x2000000 before-flash.bin
```

For a confirmed 16 MiB board use size `0x1000000` instead. Keep this backup
private: it may contain settings or credentials. If automatic connection fails,
hold BOOT, press/release RESET, release BOOT, then retry.

## A. First install or migration from the old 3 MiB layout

Write these four matching files (one command):

```sh
python -m esptool --chip esp32c5 --port PORT --baud 460800 --no-stub write-flash 0x2000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
```

No erase-all and no merged image at address zero. These writes skip NVS
0x9000–0xdfff; existing umbravox settings stay in place. Settings from unrelated
firmware are not guaranteed compatible. The SD card is not written by flashing.
Old internal filesystem/core-dump locations change; preserve the backup.
`boot_app0.bin` resets OTA selection to slot 0.

## B. App-only update after this partition migration

Use this only when the installed partition table matches this package and the
board boots app0 at 0x10000 (these builds do not implement OTA slot switching).
If uncertain, use procedure A after backup. To compare an installed table:

```sh
python -m esptool --chip esp32c5 --port PORT read-flash 0x8000 0xc00 installed-partitions.bin
```

Compare its SHA-256 with the packaged partitions.bin entry. Then update:

```sh
python -m esptool --chip esp32c5 --port PORT --baud 460800 --no-stub write-flash 0x10000 firmware.bin
```

An app-only write does NOT enlarge an old slot. Do not choose procedure B merely
because firmware was previously installed.

## Verify and recover

Wait for esptool's hash verification and reset. If necessary tap RESET without
BOOT. Check UI colors, Menu/touch, radar, retained settings, SD mounting, scanning
and your selected bridge. Confirm WDGO has one uniquely named entry per board.
GPS without an attached receiver may show acquiring; USB without a cell may
show no battery. Neither alone means the flash failed.

Keep the previous firmware AND its partition table for rollback; an old app
alone does not restore the old layout. Full-flash backup restoration also
restores all old internal settings/data and should target the same board.

## Source and license

`source.tar.gz` is the tracked source at bce092cc3c4c833d4fa895cbac4f863ff898f2ad, excluding working-tree junk
and Git history. See its platformio.ini for pinned platform and library dependencies.
Build this board with `pio run -e ws-c5-35-engine`. Dependencies must be downloaded separately.
GPL-3.0 license included. See RELEASE-NOTES.md and PARTITION-MIGRATION.md.

## Existing SD themes

Older packs on SD can override the bundled crew icons. Flashing does not modify those files. To update a matching pack, use tools/sdput.py from the source snapshot, retaining any customized pack first. Reboot once after uploading to load it.
