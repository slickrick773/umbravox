# UMBRAVOX candidate firmware

Board target: ws-c5-28-engine
Source revision: a66bd3b3cfe3fb0891fee3ec2ab50ba30653e1fd

Install using the matching browser installer manifest. Four image offsets: bootloader 0x2000, partitions 0x8000, boot_app0 0xe000, firmware 0x10000.

Use esptool 5.6.0 for command-line installation. No full-chip erase is required. Existing enrollment is retained.

See docs/BLE-BRIDGE.md and docs/XIAO-NODE-VALIDATION.md in the source archive for bounded validation. After GPS I2C faults across resets, fully remove handheld and GPS power for 30 seconds before restarting. The original GPS driver is retained; timing experiments were rejected.

Command-line installation (replace PORT with your serial port):

```sh
python -m esptool --chip esp32c5 --port PORT --baud 460800 --no-stub write-flash --flash-mode dio --flash-freq 80m --flash-size 16MB 0x2000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
```

Press RESET without holding BOOT after verification.
